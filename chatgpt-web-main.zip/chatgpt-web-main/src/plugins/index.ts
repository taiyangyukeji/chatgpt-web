import setupAssets from './assets'
import setupScrollbarStyle from './scrollbarStyle'

export { setupAssets, setupScrollbarStyle }
